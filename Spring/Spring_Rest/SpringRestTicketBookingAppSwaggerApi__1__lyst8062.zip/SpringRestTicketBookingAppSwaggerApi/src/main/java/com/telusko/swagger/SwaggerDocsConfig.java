package com.telusko.swagger;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;


@Configuration
public class SwaggerDocsConfig 
{	
	@Bean
	public Docket createDocket()
	{
		System.out.println("Docket object");
		return new Docket(DocumentationType.SWAGGER_2) //UI Screen type 
		          .select()       //To specify rest controller                           
		          .apis(RequestHandlerSelectors.basePackage("com.telusko"))   //  base package of Rest Controller          
		          .paths(PathSelectors.regex("/.*"))                          
		          .build()//Building the Docket Object
		          .apiInfo(getAppInfo()) ;
	}
	private ApiInfo getAppInfo()
	{
	     return new ApiInfoBuilder().title("TouristInfo")
	                .description("Gives Information about a Tourist")
	                .contact(new Contact("Dev-Team", "https://www.Telusko.com", "alien@telusko.com"))
	                .license("Apache 2.0")
	                .licenseUrl("http://www.apache.org/licenses/LICENSE-2.0.html")
	                .version("1.0.0")
	                .build();
	    }
	}


