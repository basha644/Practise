package com.corestocy.oop;

// Parent class
class Vehicle {
    protected String brand = "Generic Vehicle"; // Protected access allows child classes to access

    public void start() {
        System.out.println("Vehicle is starting...");
    }
}

// Child class inheriting from Vehicle
class Car extends Vehicle {
    private String model;

    public Car(String model) {
        this.model = model;
    }

    public void displayInfo() {
        System.out.println("Brand: " + brand);
        System.out.println("Model: " + model);
    }
}

public class Inheritance {
    public static void main(String[] args) {
        Car myCar = new Car("Tesla Model S");
        myCar.start(); // Inherited method
        myCar.displayInfo(); // Method from Car class
    }
}

