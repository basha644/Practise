package com.corestocy.oop;

/*Default methods provide a default implementation that can be overridden by implementing classes.
Static methods are called using the interface name and cannot be overridden.*/
interface Animal2 {
    // Abstract method
    void sound();

    // Default method
    default void eat() {
        System.out.println("Animals eat food.");
    }

    // Static method
    static void info() {
        System.out.println("This is an Animal interface.");
    }
}

class Dog2 implements Animal2 {
    @Override
    public void sound() {
        System.out.println("Dog barks.");
    }

    @Override
    public void eat() {
        System.out.println("Dogs love to eat bones.");
    }
}

public class Interface8 {
    public static void main(String[] args) {
        Animal2 myDog = new Dog2();

        // Calling overridden and default methods
        myDog.sound();
        myDog.eat();

        // Calling static method directly from the interface
        Animal2.info();
    }
}
