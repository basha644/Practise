package com.corestocy.oop;

/*Static methods belong to the abstract class and cannot be overridden.
Default methods in abstract classes are the same as concrete methods.*/
abstract class Vehicle1 {
    // Abstract method
    abstract void move();

    // Default method (concrete method with implementation)
    public void fuelType() {
        System.out.println("Most vehicles run on petrol or diesel.");
    }

    // Static method
    public static void info() {
        System.out.println("Vehicles are used for transportation.");
    }
}

class Car1 extends Vehicle1 {
    @Override
    void move() {
        System.out.println("The car moves on four wheels.");
    }

    @Override
    public void fuelType() {
        System.out.println("Cars usually run on petrol, diesel, or electricity.");
    }
}

public class AbstractClass8 {
    public static void main(String[] args) {
        Vehicle1 myCar = new Car1();

        // Calling overridden and default methods
        myCar.move();
        myCar.fuelType();

        // Calling static method directly from the abstract class
        Vehicle1.info();
    }
}


