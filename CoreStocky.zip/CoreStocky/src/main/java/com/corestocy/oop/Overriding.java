package com.corestocy.oop;

// Parent class
class Animal {
    public Animal sound() {
        System.out.println("Animals make sound");
        return new Animal();
    }
}

// Child class overriding the method
class Dog extends Animal {
    @Override
//    public Animal sound() {   old way
        public Dog sound() {    // Co-variant return type (Dog is a subclass of Animal)
            System.out.println("Dog barks");
        return new Dog();
    }

    // Act as special method not over-ride method
    public Dog sound(int num) {
        System.out.println("Act as special method");
        return new Dog();
    }

    // specialize method access child reference only
    public void walk(){
        System.out.println("Dog walking");
    }
}

public class Overriding {
    public static void main(String[] args) {

        Animal myAnimal = new Dog(); // Upcasting
        myAnimal.sound(); // Calls overridden method in Dog class

//        myAnimal.walk();  we can't access bcz parent reference
        Dog dog = new Dog(); // Upcasting
        dog.walk();
        dog.sound(1); //special method

    }
}

/*Rules for Co-variant Return Types:
The overriding method's return type in the subclass(child) must be a subclass of the return type declared in the superclass(parent).
This feature was introduced in Java 5.

Key Benefits of Co-variant Return Types:
Type Safety: It eliminates the need for explicit typecasting when working with subclass-specific methods or fields.
Specialization: Allows subclass methods to provide more specific implementations, which is closer to real-world scenarios.
Flexibility: Improves readability and maintainability by enabling polymorphism with more specific return types.*/
