package com.corestocy.oop;

/*Interfaces can complement abstract classes to provide multiple inheritance-like behavior.
Abstract classes are better suited for shared state and common behaviors, while interfaces define capabilities or contracts.*/

interface Flyable {
    void fly();

    default void takeOff() {
        System.out.println("Taking off...");
    }

    static void info() {
        System.out.println("Flyable interface provides flying capabilities.");
    }
}

abstract class Bird {
    abstract void chirp();

    public void layEggs() {
        System.out.println("Birds lay eggs.");
    }
}

class Sparrow extends Bird implements Flyable {
    @Override
    void chirp() {
        System.out.println("Sparrow chirps.");
    }

    @Override
    public void fly() {
        System.out.println("Sparrow flies short distances.");
    }
}

public class AbstractionDemo {
    public static void main(String[] args) {
        Sparrow sparrow = new Sparrow();

        // Methods from abstract class
        sparrow.chirp();
        sparrow.layEggs();

        // Methods from interface
        sparrow.fly();
        sparrow.takeOff();
        Flyable.info(); // Static method from the interface
    }
}

